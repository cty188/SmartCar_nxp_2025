import math
import time
import random

class MahonyFilter:
    """Mahony滤波器Python实现（无Numpy依赖）"""
    
    def __init__(self, Kp=0.5, Ki=0.01, dt=0.01):
        """
        初始化Mahony滤波器
        :param Kp: 比例增益
        :param Ki: 积分增益
        :param dt: 采样时间间隔(秒)
        """
        # 滤波器参数
        self.Kp = Kp
        self.Ki = Ki
        self.dt = dt
        
        # 状态变量
        self.q0 = 1.0  # 四元数w
        self.q1 = 0.0  # 四元数x
        self.q2 = 0.0  # 四元数y
        self.q3 = 0.0  # 四元数z
        
        # 误差积分项
        self.exInt = 0.0
        self.eyInt = 0.0
        self.ezInt = 0.0
        
        # 旋转矩阵 (3x3)
        self.rMat = [
            [1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0]
        ]
        
        # 输出姿态角
        self.pitch = 0.0
        self.roll = 0.0
        self.yaw = 0.0
        
        # 传感器数据
        self.gyro = [0.0, 0.0, 0.0]  # [x, y, z]
        self.acc = [0.0, 0.0, 0.0]   # [x, y, z]
    
    def rotation_matrix_update(self):
        """更新旋转矩阵"""
        q0, q1, q2, q3 = self.q0, self.q1, self.q2, self.q3
        
        # 计算四元数乘积项
        q1q1 = q1 * q1
        q2q2 = q2 * q2
        q3q3 = q3 * q3
        
        q0q1 = q0 * q1
        q0q2 = q0 * q2
        q0q3 = q0 * q3
        q1q2 = q1 * q2
        q1q3 = q1 * q3
        q2q3 = q2 * q3
        
        # 更新旋转矩阵
        self.rMat[0][0] = 1.0 - 2.0 * q2q2 - 2.0 * q3q3
        self.rMat[0][1] = 2.0 * (q1q2 - q0q3)
        self.rMat[0][2] = 2.0 * (q1q3 + q0q2)
        
        self.rMat[1][0] = 2.0 * (q1q2 + q0q3)
        self.rMat[1][1] = 1.0 - 2.0 * q1q1 - 2.0 * q3q3
        self.rMat[1][2] = 2.0 * (q2q3 - q0q1)
        
        self.rMat[2][0] = 2.0 * (q1q3 - q0q2)
        self.rMat[2][1] = 2.0 * (q2q3 + q0q1)
        self.rMat[2][2] = 1.0 - 2.0 * q1q1 - 2.0 * q2q2
    
    def vector_cross(self, a, b):
        """计算两个向量的叉积"""
        return [
            a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0]
        ]
    
    def vector_norm(self, v):
        """计算向量的模"""
        return math.sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2])
    
    def vector_normalize(self, v):
        """归一化向量"""
        norm = self.vector_norm(v)
        if norm > 1e-6:  # 避免除以零
            return [v[0]/norm, v[1]/norm, v[2]/norm]
        return v
    
    def input_data(self, gyro, acc):
        """
        输入传感器数据
        :param gyro: 陀螺仪数据 [x, y, z] (度/秒)
        :param acc: 加速度计数据 [x, y, z] (任意单位)
        """
        self.gyro = list(gyro)
        self.acc = list(acc)
    
    def update(self):
        """执行Mahony滤波更新"""
        # 归一化加速度计数据
        acc_norm = self.vector_norm(self.acc)
        if acc_norm > 1e-6:  # 避免除以零
            self.acc = [x/acc_norm for x in self.acc]
        
        # 计算重力方向误差
        # 估计的重力方向是旋转矩阵的第三行
        estimated_gravity = self.rMat[2]
        
        # 计算加速度计测量值与估计重力方向的叉积
        error = self.vector_cross(self.acc, estimated_gravity)
        ex, ey, ez = error
        
        # 积分误差
        self.exInt += self.Ki * ex * self.dt
        self.eyInt += self.Ki * ey * self.dt
        self.ezInt += self.Ki * ez * self.dt
        
        # 修正陀螺仪读数
        gyro_corrected = [
            self.gyro[0] + self.Kp * ex + self.exInt,
            self.gyro[1] + self.Kp * ey + self.eyInt,
            self.gyro[2] + self.Kp * ez + self.ezInt
        ]
        
        # 将陀螺仪数据从度/秒转换为弧度/秒
        gyro_rad = [
            math.radians(gyro_corrected[0]),
            math.radians(gyro_corrected[1]),
            math.radians(gyro_corrected[2])
        ]
        gx, gy, gz = gyro_rad
        
        # 四元数导数 (一阶近似)
        q0, q1, q2, q3 = self.q0, self.q1, self.q2, self.q3
        half_dt = 0.5 * self.dt
        
        # 四元数更新
        self.q0 += (-q1 * gx - q2 * gy - q3 * gz) * half_dt
        self.q1 += ( q0 * gx + q2 * gz - q3 * gy) * half_dt
        self.q2 += ( q0 * gy - q1 * gz + q3 * gx) * half_dt
        self.q3 += ( q0 * gz + q1 * gy - q2 * gx) * half_dt
        
        # 归一化四元数
        q_norm = math.sqrt(self.q0**2 + self.q1**2 + self.q2**2 + self.q3**2)
        if q_norm > 1e-6:  # 避免除以零
            self.q0 /= q_norm
            self.q1 /= q_norm
            self.q2 /= q_norm
            self.q3 /= q_norm
        
        # 更新旋转矩阵
        self.rotation_matrix_update()
        
        # 更新姿态角
        self.update_attitude()
    
    def update_attitude(self):
        """从旋转矩阵计算姿态角"""
        # 旋转矩阵元素
        r20 = self.rMat[2][0]
        r21 = self.rMat[2][1]
        r22 = self.rMat[2][2]
        r10 = self.rMat[1][0]
        r00 = self.rMat[0][0]
        
        # 计算俯仰角 (pitch)
        self.pitch = -math.asin(r20)
        
        # 计算滚转角 (roll)
        self.roll = math.atan2(r21, r22)
        
        # 计算偏航角 (yaw)
        self.yaw = math.atan2(r10, r00)
    
    def get_attitude_degrees(self):
        """获取姿态角（度）"""
        pitch_deg = math.degrees(self.pitch)
        roll_deg = math.degrees(self.roll)
        yaw_deg = math.degrees(self.yaw)
        return pitch_deg, roll_deg, yaw_deg
    
    def get_attitude_radians(self):
        """获取姿态角（弧度）"""
        return self.pitch, self.roll, self.yaw
    
    def reset(self, pitch=0.0, roll=0.0, yaw=0.0):
        """重置滤波器状态"""
        # 将欧拉角转换为四元数
        cy = math.cos(yaw * 0.5)
        sy = math.sin(yaw * 0.5)
        cp = math.cos(pitch * 0.5)
        sp = math.sin(pitch * 0.5)
        cr = math.cos(roll * 0.5)
        sr = math.sin(roll * 0.5)
        
        self.q0 = cr * cp * cy + sr * sp * sy
        self.q1 = sr * cp * cy - cr * sp * sy
        self.q2 = cr * sp * cy + sr * cp * sy
        self.q3 = cr * cp * sy - sr * sp * cy
        
        # 归一化四元数
        q_norm = math.sqrt(self.q0**2 + self.q1**2 + self.q2**2 + self.q3**2)
        if q_norm > 1e-6:
            self.q0 /= q_norm
            self.q1 /= q_norm
            self.q2 /= q_norm
            self.q3 /= q_norm
        
        # 重置误差积分项
        self.exInt = 0.0
        self.eyInt = 0.0
        self.ezInt = 0.0
        
        # 更新旋转矩阵和姿态角
        self.rotation_matrix_update()
        self.update_attitude()
    
    def print_state(self):
        """打印当前滤波器状态（用于调试）"""
        print(f"四元数: [{self.q0:.4f}, {self.q1:.4f}, {self.q2:.4f}, {self.q3:.4f}]")
        print(f"姿态角: Pitch={math.degrees(self.pitch):.2f}°, Roll={math.degrees(self.roll):.2f}°, Yaw={math.degrees(self.yaw):.2f}°")
        print(f"误差积分: exInt={self.exInt:.4f}, eyInt={self.eyInt:.4f}, ezInt={self.ezInt:.4f}")
        print("旋转矩阵:")
        for row in self.rMat:
            print(f"[{row[0]:.4f}, {row[1]:.4f}, {row[2]:.4f}]")
    
    def mohony_calculate(self, gyro_data, accel_data):
        """简化的更新方法：输入数据、更新状态并返回姿态角"""
        # 输入数据到滤波器
        self.input_data(gyro_data, accel_data)
        
        # 更新滤波器状态
        self.update()
        
        # 获取并返回姿态角
        return self.get_attitude_degrees()

def read_gyro():
    """模拟读取陀螺仪数据（度/秒）"""
    # 实际系统中替换为真实传感器读取代码
    return [
        random.uniform(-0.5, 0.5) + 0.1 * math.sin(time.time()),  # X轴
        random.uniform(-0.5, 0.5) + 0.1 * math.cos(time.time()),  # Y轴
        random.uniform(-0.5, 0.5) + 0.05 * math.sin(0.5 * time.time())  # Z轴
    ]

def read_accel():
    """模拟读取加速度计数据（m/s²）"""
    # 实际系统中替换为真实传感器读取代码
    return [
        random.uniform(-0.2, 0.2) + 0.5 * math.sin(0.3 * time.time()),  # X轴
        random.uniform(-0.2, 0.2) + 0.5 * math.cos(0.3 * time.time()),  # Y轴
        9.8 + random.uniform(-0.1, 0.1)  # Z轴（重力）
    ]

def control_system(pitch, roll, yaw):
    """使用姿态角进行控制系统操作"""
    # 实际系统中替换为真实控制逻辑
    # 例如：print(f"控制系统使用姿态角: Pitch={pitch:.2f}°, Roll={roll:.2f}°, Yaw={yaw:.2f}°")
    # 这里可以添加PID控制、姿态稳定等逻辑
    pass

def mahony_main_loop():
    """Mahony滤波器主控制循环"""
    # 初始化Mahony滤波器
    # 参数：Kp=0.5, Ki=0.01, dt=0.01 (100Hz)
    mahony = MahonyFilter(Kp=0.5, Ki=0.01, dt=0.01)
    
    print("Mahony滤波器启动...")
    
    # 初始静止校准（实际系统中可能需要）
    print("进行初始校准...")
    for _ in range(100):  # 100次采样（约1秒）
        gyro_data = [0, 0, 0]  # 假设初始静止
        accel_data = [0, 0, 9.8]  # 假设初始水平
        mahony.input_data(gyro_data, accel_data)
        mahony.update()
        time.sleep(0.01)
    print("初始校准完成!")
    
    # 主循环
    loop_count = 0
    start_time = time.time()
    
    while True:
        loop_start = time.time()
        
        # 读取传感器数据
        gyro_data = read_gyro()
        accel_data = read_accel()
        
        # 更新并获取姿态角（使用新增的方法）
        pitch, roll, yaw = mahony.mohony_calculate(gyro_data, accel_data)
        
        # 使用姿态角进行控制
        control_system(pitch, roll, yaw)
        
        # 每1秒输出一次状态
        if loop_count % 100 == 0:  # 每100次更新输出一次（约1秒）
            current_time = time.time() - start_time
            print(f"\n时间: {current_time:.1f}s")
            print(f"传感器数据 - 陀螺仪: [{gyro_data[0]:.2f}, {gyro_data[1]:.2f}, {gyro_data[2]:.2f}]°/s")
            print(f"传感器数据 - 加速度计: [{accel_data[0]:.2f}, {accel_data[1]:.2f}, {accel_data[2]:.2f}]m/s²")
            print(f"滤波姿态 - Pitch: {pitch:.2f}°, Roll: {roll:.2f}°, Yaw: {yaw:.2f}°")
        
        loop_count += 1
        
        # 计算并等待直到下一个采样时间
        elapsed = time.time() - loop_start
        sleep_time = max(0.001, 0.01 - elapsed)  # 确保0.01秒间隔（100Hz）
        time.sleep(sleep_time)

# 运行测试
if __name__ == "__main__":
    try:
        mahony_main_loop()
    except KeyboardInterrupt:
        print("\nMahony滤波器已停止")